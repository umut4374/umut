<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Classima;
?>
<div class="listing-archive-noresult"><?php esc_html_e( 'No results found', 'classima' );?></div>